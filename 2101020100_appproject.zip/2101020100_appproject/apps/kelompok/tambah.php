<?php
    session_start();
    if (isset($_POST['tambah_kelompok'])) {
        
        //Include file koneksi, untuk koneksikan ke database
        include '../../config/database.php';
        
        //Fungsi untuk mencegah inputan karakter yang tidak sesuai
        function input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        //Cek apakah ada kiriman form dari method post
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            //Memulai transaksi
            mysqli_query($kon,"START TRANSACTION");

            $nama_kelompok=input($_POST["nama_kelompok"]);
            $kecamatan=input($_POST["kecamatan"]);
            $kid_kelompok=input($_POST["kid_kelompok"]);
            $mulai_kegiatan=input($_POST["mulai_kegiatan"]);
            $akhir_kegiatan=input($_POST["akhir_kegiatan"]);
            $notelp_ketua=input($_POST["notelp_ketua"]);
            $ekstensi_diperbolehkan	= array('png','jpg','jpeg','gif');
            $foto_profil = $_FILES['foto']['name'];
            $x = explode('.', $foto);
            $ekstensi = strtolower(end($x));
            $ukuran	= $_FILES['foto']['size'];
            $file_tmp = $_FILES['foto']['tmp_name'];

            include '../../config/database.php';
            $query = mysqli_query($kon, "SELECT max(id_kelompok) as id_terbesar FROM tbl_kelompok");
            $ambil= mysqli_fetch_array($query);
            $id_kelompok = $ambil['id_terbesar'];
            $id_kelompok++;
            //Membuat kode admin
            $huruf = "K";
            $kode_kelompok = $huruf . sprintf("%03s", $id_kelompok);

            $sql="insert into tbl_user (kode_pengguna) values
            ('$kode_kelompok')";

            //Menyimpan ke tabel pengguna
            $simpan_pengguna=mysqli_query($kon,$sql);

            if (!empty($foto)){
                if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
                    //Mengupload gambar
                    move_uploaded_file($file_tmp, 'foto/'.$foto);
                    //Sql jika menggunakan foto
                    $sql="insert into tbl_kelompok (kode_kelompok,nama_kelompok,kecamatan,kid_kelompok,mulai_kegiatan,akhir_kegiatan,notelp_ketua,foto_profil) values
                    ('$kode_kelompok','$nama_kelompok','$kecamatan','$kid_kelompok','$mulai_kegiatan','$akhir_kegiatan','$notelp_ketua','$foto_profil')";
                }
            }else {
                //Sql jika tidak menggunakan foto, maka akan memakai gambar_default.png
                $foto="foto_default.png";
                $sql="insert into tbl_kelompok (kode_kelompok,nama_kelompok,kecamatan,kid_kelompok,mulai_kegiatan,akhir_kegiatan,notelp_ketua,foto_profil) values
                ('$kode_kelompok','$nama_kelompok','$kecamatan','$kid_kelompok','$mulai_kegiatan','$akhir_kegiatan','$notelp_ketua','$foto_profil')";
            }

            //Menyimpan ke tabel admin
            $simpan_kelompok=mysqli_query($kon,$sql);
            
            if ($simpan_pengguna and $simpan_kelompok) {
                mysqli_query($kon,"COMMIT");
                header("Location:../../index.php?page=anggota&add=berhasil");
            }
            else {
                mysqli_query($kon,"ROLLBACK");
                header("Location:../../index.php?page=anggota&add=gagal");
            }
        }
    }
?>

<form action="apps/kelompok/tambah.php" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <label>Nama Kelompok :</label>
                <input type="text" name="nama_kelompok" class="form-control" placeholder="Masukkan Nama Kelompok" required>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Kecamatan :</label>
                <input type="text" name="kecamatan" class="form-control" placeholder="Masukkan Nama Kecamatan" required>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Kode ID Kelompok :</label>
                <input type="text" name="kid_kelompok" class="form-control" placeholder="Masukkan Kode ID Kelompok" required>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Mulai Kegiatan :</label>
                <input type="date" name="mulai_kegiatan" class="form-control" required>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Akhir Kegiatan :</label>
                <input type="date" name="akhir_kegiatan" class="form-control" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <label>Nomor Telepon Ketua :</label>
                <input type="text" name="notelp_ketua" class="form-control" placeholder="Masukan Nomor Telepon" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-5">
            <div class="form-group">
                <div id="msg"></div>
                <label>Foto Profil :</label>
                <input type="file" name="foto_profil" class="file" >
                    <div class="input-group my-3">
                        <input type="text" class="form-control" disabled placeholder="Upload Foto" id="file">
                        <div class="input-group-append">
                            <button type="button" id="pilih_foto" class="browse btn btn-info"><i class="fa fa-search"></i> Pilih</button>
                        </div>
                    </div>
                <img src="source/img/size.png" id="preview" class="img-thumbnail">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <button type="submit" name="tambah_kelompok" id="Submit" class="btn btn-success"><i class="fa fa-plus"></i> Daftar</button>
            <button type="reset" class="btn btn-warning"><i class="fa fa-trash"></i> Reset</button>
        </div>
    </div>
</form>

<style>
    .file {
    visibility: hidden;
    position: absolute;
    }
</style>

<script>
    $(document).on("click", "#pilih_foto", function() {
    var file = $(this).parents().find(".file");
    file.trigger("click");
    });
    $('input[type="file"]').change(function(e) {
    var fileName = e.target.files[0].name;
    $("#file").val(fileName);

    var reader = new FileReader();
    reader.onload = function(e) {
        // get loaded data and render thumbnail.
        document.getElementById("preview").src = e.target.result;
    };
    // read the image file as a data URL.
    reader.readAsDataURL(this.files[0]);
    });
</script>
