<?php
session_start();
    include '../../config/database.php';
    mysqli_query($kon,"START TRANSACTION");

    $id_kelompok=$_GET['id_kelompok'];
    $kode_kelompok=$_GET['kode_kelompok'];

    $hapus_admin=mysqli_query($kon,"DELETE FROM tbl_user WHERE kode_pengguna='$kode_pengguna'");
    $hapus_pengguna=mysqli_query($kon, "DELETE FROM tbl_kelompok WHERE id_kelompok='$id_kelompok'");

    if ($hapus_admin and $hapus_pengguna) {
        mysqli_query($kon,"COMMIT");
        header("Location:../../index.php?page=kelompok&hapus=berhasil");
    }
    else {
        mysqli_query($kon,"ROLLBACK");
        header("Location:../../index.php?page=kelompok&hapus=gagal");

    }

?>