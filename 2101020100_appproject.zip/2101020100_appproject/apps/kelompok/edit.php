<?php
session_start();
    if (isset($_POST['edit_kelompok'])) {
        include '../../config/database.php';
        function input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            mysqli_query($kon,"START TRANSACTION");
            $id_kelompok=input($_POST["id_kelompok"]);
            $nama_kelompok=input($_POST["nama_kelompok"]);
            $kecamatan=input($_POST["kecamatan"]);
            $kid_kelompok=input($_POST["kid_kelompok"]);
            $mulai_kegiatan=input($_POST["mulai_kegiatan"]);
            $akhir_kegiatan=input($_POST["akhir_kegiatan"]);
            $notelp_ketua=input($_POST["notelp_ketua"]);
            $ekstensi_diperbolehkan	= array('png','jpg','jpeg','gif');
            $foto = $_FILES['foto']['name'];
            $x = explode('.', $foto);
            $ekstensi = strtolower(end($x));
            $ukuran	= $_FILES['foto']['size'];
            $file_tmp = $_FILES['foto']['tmp_name'];
            $pengguna=input($_POST["pengguna"]);

            $foto_saat_ini=$_POST['foto_saat_ini'];
            $foto_baru = $_FILES['foto_baru']['name'];
            $ekstensi_diperbolehkan	= array('png','jpg','jpeg','gif');
            $x = explode('.', $foto_baru);
            $ekstensi = strtolower(end($x));
            $ukuran	= $_FILES['foto_baru']['size'];
            $file_tmp = $_FILES['foto_baru']['tmp_name'];


        if (!empty($foto_baru)){
            if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
                move_uploaded_file($file_tmp, 'foto/'.$foto_baru);
                if ($foto_saat_ini!='foto_default.png'){
                    unlink("foto/".$foto_saat_ini);
                }
                $sql="UPDATE tbl_kelompok SET
                    nama_kelompok='$nama_kelompok',
                    kecamatan='$kecamatan',
                    kid_kelompok='$kid_kelompok',
                    mulai_kegiatan='$mulai_kegiatan',
                    akhir_kegiatan='$akhir_kegiatan',
                    notelp_ketua='$notelp_ketua',
                    foto_profil='$foto_baru
                    WHERE id_kelompok=$id_kelompok";
                }
            } else {
                $sql="UPDATE tbl_kelompok SET
                    nama='$nama',
                    kecamatan='$kecamatan',
                    kid_kelompok='$kid_kelompok',
                    mulai_kegiatan='$mulai_kegiatan',
                    akhir_kegiatan='$akhir_kegiatan',
                    notelp_ketua='$notelp_ketua',
                    WHERE id_kelompok=$id_kelompok";
            }

            $edit_kelompok=mysqli_query($kon,$sql);
            if ($edit_kelompok) {
                mysqli_query($kon,"COMMIT");
                // header("Location:../../index.php?page=anggota&edit=berhasil");
            } else {
                mysqli_query($kon,"ROLLBACK");
                // header("Location:../../index.php?page=anggota&edit=gagal");
            }
        }
    }
?>

<?php 
    include '../../config/database.php';
    $id_kelompok=$_POST["id_kelompok"];
    $sql="select * from tbl_kelompok where id_kelompok=$id_kelompok limit 1";
    $hasil=mysqli_query($kon,$sql);
    $data = mysqli_fetch_array($hasil); 
?>

<form action="apps/kelompok/edit.php" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <label>Nama Kelompok :</label>
                <input type="hidden" name="id_kelompok" class="form-control" value="<?php echo $data['id_kelompok'];?>">
                <input type="text" name="nama_kelompok" class="form-control" value="<?php echo $data['nama_kelompok'];?>" placeholder="Masukkan Nama Kelompok" required>

            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Kode ID Kelompok :</label>
                <input type="text" name="kid_kelompok" class="form-control" value="<?php echo $data['kid_kelompok'];?>" placeholder="Masukkan Kode ID Kelompok" required>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Kecamatan :</label>
                <input type="text" name="kecamatan" class="form-control" value="<?php echo $data['kecamatan'];?>" placeholder="Masukkan Kecamatan" required>
            </div>
        </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <label>Mulai Kegiatan :</label>
                <input type="date" name="mulai_kegiatan" class="form-control" value="<?php echo $data['mulai_kegiatan'];?>" required>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <label>Akhir Kegiatan :</label>
                <input type="date" name="akhir_kegiatan" class="form-control" value="<?php echo $data['akhir_kegiatan'];?>" required>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Nomor Telepon Ketua :</label>
                <input type="text" name="notelp_ketua" class="form-control" placeholder="Masukan No Telp" value="<?php echo $data['notelp_ketua'];?>" required>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
            <label>Foto :</label><br>
                <img src="<?php 
                    echo !empty($data['foto']) 
                        ? 'http://' . $_SERVER['HTTP_HOST'] . '/udahfix/apps/kelompok/foto/' . htmlspecialchars($data['foto']) 
                        : 'http://' . $_SERVER['HTTP_HOST'] . '/udahfix/apps/kelompok/foto/foto_default.png'; 
                ?>" width="120" alt="Image">
                <input type="hidden" name="foto_saat_ini" value="<?php echo !empty($data['foto']) 
                        ? 'http://' . $_SERVER['HTTP_HOST'] . '/udahfix/apps/kelompok/foto/' . htmlspecialchars($data['foto']) 
                        : 'http://' . $_SERVER['HTTP_HOST'] . '/udahfix/apps/kelompok/foto/foto_default.png';?>" class="form-control" />
            </div>
            <div class="col-sm-4">
                <div id="msg"></div>
                <label>Upload Foto Baru:</label>
                <input type="file" name="foto_baru" class="file" >
                    <div class="input-group my-3">
                        <input type="text" class="form-control" disabled placeholder="Upload File" id="file">
                        <div class="input-group-append">
                            <button type="button" id="pilih_foto" class="browse btn btn-info"><i class="fa fa-search"></i> Pilih Foto</button>
                        </div>
                    </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    <br>
                    <button type="submit" name="edit_kelompok" id="Submit" class="btn btn-warning" ><i class="fa fa-edit"></i> Update</button>
                </div>
            </div>
        </div>
</form>

<style>
    .file {
    visibility: hidden;
    position: absolute;
    }
</style>

<script>
    $(document).on("click", "#pilih_foto", function() {
    var file = $(this).parents().find(".file");
    file.trigger("click");
    });
    $('input[type="file"]').change(function(e) {
    var fileName = e.target.files[0].name;
    $("#file").val(fileName);
    var reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById("preview").src = e.target.result;
    };
    reader.readAsDataURL(this.files[0]);
    });
</script>