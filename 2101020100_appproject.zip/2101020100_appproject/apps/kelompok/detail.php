<?php 
    include '../../config/database.php';
    include '../../config/function.php';
    $id_kelompok=$_POST["id_kelompok"];
    $sql="SELECT * FROM tbl_kelompok WHERE id_kelompok=$id_kelompok LIMIT 1";
    $hasil=mysqli_query($kon,$sql);
    $data = mysqli_fetch_array($hasil); 
?>

<table class="table">
    <tbody>
        <tr>
            <td>Nama Kelompok</td>
            <td width="75%">: <?php echo $data['nama_kelompok'];?></td>
        </tr>
        <tr>
            <td>Kode ID Kelompok</td>
            <td width="75%">: <?php echo $data['kid_kelompok'];?></td>
        </tr>
        <tr>
            <td>Kecamatan</td>
            <td width="75%">: <?php echo $data['kecamatan'];?></td>
        </tr>
        <tr>
            <td>Mulai Kegiatan</td>
            <td width="75%">: <?php $tgl = date("d", strtotime($data['mulai_kegiatan']));
                                    $bulan = date("m", strtotime($data['mulai_kegiatan']));
                                    $tahun = date("Y", strtotime($data['mulai_kegiatan']));
                                    echo $tgl.' '.MendapatkanBulan($bulan).' '.$tahun ?></td>
        </tr>
        <tr>
            <td>Akhir Kegiatan</td>
            <td width="75%">: <?php $tgl = date("d", strtotime($data['akhir_kegiatan']));
                                    $bulan = date("m", strtotime($data['akhir_kegiatan']));
                                    $tahun = date("Y", strtotime($data['akhir_kegiatan']));
                                    echo $tgl.' '.MendapatkanBulan($bulan).' '.$tahun ?></td>
        </tr>
        <tr>
            <td>Nomor Telepon Ketua</td>
            <td width="75%">: <?php echo $data['notelp_ketua'];?></td>
        </tr>
    </tbody>
</table>