<?php
    session_start();
    if (isset($_POST['simpan_kegiatan'])) {

        include '../../config/database.php';
        
        function input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        $id_kelompok=$_POST["id_kelompok"];
        $tanggal= $_POST["tanggal"];
        $waktu_awal = $_POST["waktu_awal"];
        $waktu_akhir = $_POST["waktu_akhir"];
        $kegiatan = $_POST["kegiatan"];
        
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $sql = "INSERT INTO tbl_kegiatan (id_kelompok,kegiatan,waktu_awal,waktu_akhir,tanggal) 
        VALUES ('$id_kelompok','$kegiatan','$waktu_awal','$waktu_akhir','$tanggal')";
        $simpan_kegiatan=mysqli_query($kon,$sql);

        // validasi data
        if ($simpan_kegiatan) {
            mysqli_query($kon,"COMMIT");
            header("Location:../../index.php?page=data_kegiatan&tambah=berhasil");
        }

        else {
            mysqli_query($kon,"ROlLBACK");
            header("Location:../../index.php?page=data_kegiatan&tambah=gagal");
        }
        }
    }
?>

<form action="apps/data_kegiatan/tambah.php" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <label>Nama Kelompok :</label>
                <select class="form-control" id="id_kelompok" name="id_kelompok"  required>
                <?php
                    // Tampilkan data nama_kelompok dan id_kelompok pada elemen select option
                    include '../../config/database.php';
                    $query = "SELECT id_kelompok, nama_kelompok FROM tbl_kelompok";
                    $result = mysqli_query($kon, $query);
                    while ($data = mysqli_fetch_assoc($result)) {
                    echo "<option value='" . $data['id_kelompok'] . "'>" . $data['nama_kelompok'] . "</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Tanggal Kegiatan :</label>
                <input type="date" name="tanggal" id="tanggal" class="form-control"  value="">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Waktu Awal Kegiatan :</label>
                <input type="time" name="waktu_awal" id="waktu_awal" class="form-control"  value="">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Waktu Akhir Kegiatan:</label>
                <input type="time" name="waktu_akhir" id="waktu_akhir" class="form-control"  value="">
            </div>
        </div>
        <div class="col-sm-12">
            <div class="form-group">
                <label>Kegiatan :</label>
                <input type="text" name="kegiatan" id="kegiatan" class="form-control"  value="" placeholder="Masukkan Kegiatan Harian">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <br>
                <button type="submit" name="simpan_kegiatan" id="simpan_kegiatan" class="btn btn-success" ><i class="fa fa-plus"></i> Simpan</button>
                <button type="clear" class="btn btn-warning" ><i class="fa fa-trash"></i> Hapus</button>
            </div>
        </div>
    </div>
</form>