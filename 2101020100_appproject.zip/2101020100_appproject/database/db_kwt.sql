-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Jan 2023 pada 14.31
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kwt`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_absensi`
--

CREATE TABLE `tbl_absensi` (
  `id_absensi` int(15) NOT NULL,
  `id_kelompok` int(15) DEFAULT NULL,
  `status` int(15) DEFAULT NULL,
  `waktu` time DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_absensi`
--

INSERT INTO `tbl_absensi` (`id_absensi`, `id_kelompok`, `status`, `waktu`, `tanggal`) VALUES
(1, 1, 1, '08:05:00', '2024-10-06'),
(2, 1, 1, '08:10:00', '2024-10-13'),
(3, 1, 1, '08:15:00', '2024-10-20'),
(4, 1, 1, '08:20:00', '2024-10-27'),
(5, 2, 1, '08:05:00', '2024-10-06'),
(6, 2, 1, '08:10:00', '2024-10-13'),
(7, 2, 1, '08:15:00', '2024-10-20'),
(8, 2, 1, '08:20:00', '2024-10-27'),
(9, 3, 1, '08:05:00', '2024-10-06'),
(10, 3, 1, '08:10:00', '2024-10-13'),
(11, 3, 2, '08:15:00', '2024-10-20'),
(12, 3, 1, '08:20:00', '2024-10-27'),
(13, 4, 1, '08:05:00', '2024-10-06'),
(14, 4, 1, '08:10:00', '2024-10-13'),
(15, 4, 1, '08:15:00', '2024-10-20'),
(16, 4, 1, '08:20:00', '2024-10-27'),
(17, 5, 1, '08:05:00', '2024-10-06'),
(18, 5, 1, '08:10:00', '2024-10-13'),
(19, 5, 1, '08:15:00', '2024-10-20'),
(20, 5, 1, '08:20:00', '2024-10-27'),
(21, 6, 1, '08:05:00', '2024-10-06'),
(22, 6, 1, '08:10:00', '2024-10-13'),
(23, 6, 1, '08:15:00', '2024-10-20'),
(24, 6, 1, '08:20:00', '2024-10-27'),
(25, 7, 1, '08:05:00', '2024-10-06'),
(26, 7, 1, '08:10:00', '2024-10-13'),
(27, 7, 1, '08:15:00', '2024-10-20'),
(28, 7, 2, '08:20:00', '2024-10-27'),
(29, 8, 1, '08:05:00', '2024-10-06'),
(30, 8, 2, '08:10:00', '2024-10-13'),
(31, 8, 1, '08:15:00', '2024-10-20'),
(32, 8, 1, '08:20:00', '2024-10-27'),
(33, 9, 1, '08:05:00', '2024-10-06'),
(34, 9, 1, '08:10:00', '2024-10-13'),
(35, 9, 1, '08:15:00', '2024-10-20'),
(36, 9, 1, '08:20:00', '2024-10-27'),
(37, 10, 1, '08:05:00', '2024-10-06'),
(38, 10, 1, '08:10:00', '2024-10-13'),
(39, 10, 1, '08:15:00', '2024-10-20'),
(40, 10, 1, '08:20:00', '2024-10-27'),
(41, 11, 1, '08:05:00', '2024-10-06'),
(42, 11, 1, '08:10:00', '2024-10-13'),
(43, 11, 1, '08:15:00', '2024-10-20'),
(44, 11, 1, '08:20:00', '2024-10-27'),
(45, 12, 1, '08:05:00', '2024-10-06'),
(46, 12, 1, '08:10:00', '2024-10-13'),
(47, 12, 1, '08:15:00', '2024-10-20'),
(48, 12, 2, '08:20:00', '2024-10-27'),
(49, 13, 1, '08:05:00', '2024-10-06'),
(50, 13, 1, '08:10:00', '2024-10-13'),
(51, 13, 1, '08:15:00', '2024-10-20'),
(52, 13, 1, '08:20:00', '2024-10-27'),
(53, 14, 1, '08:05:00', '2024-10-06'),
(54, 14, 1, '08:10:00', '2024-10-13'),
(55, 14, 1, '08:15:00', '2024-10-20'),
(56, 14, 1, '08:20:00', '2024-10-27'),
(57, 15, 1, '08:05:00', '2024-10-06'),
(58, 15, 1, '08:10:00', '2024-10-13'),
(59, 15, 1, '08:15:00', '2024-10-20'),
(60, 15, 1, '08:20:00', '2024-10-27'),
(61, 16, 1, '08:05:00', '2024-10-06'),
(62, 16, 1, '08:10:00', '2024-10-13'),
(63, 16, 1, '08:15:00', '2024-10-20'),
(64, 16, 1, '08:20:00', '2024-10-27'),
(65, 17, 1, '08:05:00', '2024-10-06'),
(66, 17, 1, '08:10:00', '2024-10-13'),
(67, 17, 1, '08:15:00', '2024-10-20'),
(68, 17, 1, '08:20:00', '2024-10-27'),
(69, 18, 2, '08:05:00', '2024-10-06'),
(70, 18, 1, '08:10:00', '2024-10-13'),
(71, 18, 1, '08:15:00', '2024-10-20'),
(72, 18, 1, '08:20:00', '2024-10-27'),
(73, 19, 1, '08:05:00', '2024-10-06'),
(74, 19, 1, '08:10:00', '2024-10-13'),
(75, 19, 1, '08:15:00', '2024-10-20'),
(76, 19, 1, '08:20:00', '2024-10-27'),
(77, 20, 1, '08:05:00', '2024-10-06'),
(78, 20, 1, '08:10:00', '2024-10-13'),
(79, 20, 1, '08:15:00', '2024-10-20'),
(80, 20, 1, '08:20:00', '2024-10-27');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id_admin` int(5) NOT NULL,
  `kode_admin` varchar(5) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `nim` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_admin`
--

INSERT INTO `tbl_admin` (`id_admin`, `kode_admin`, `nama`, `nim`, `email`) VALUES
(1, 'A0001', 'Amanda Faatihah Aulia', '2101020100', '2101020100@student.umrah.ac.id');


-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_alasan`
--

CREATE TABLE `tbl_alasan` (
  `id_alasan` int(5) NOT NULL,
  `id_kelompok` int(5) DEFAULT NULL,
  `alasan` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_alasan`
--

INSERT INTO `tbl_alasan` (`id_alasan`, `id_kelompok`, `alasan`, `tanggal`) VALUES
(1, 3, 'Kesibukan pribadi anggota', '2024-10-20'),
(2, 7, 'Kesibukan pribadi anggota', '2024-10-27'),
(3, 8, 'Kesibukan pribadi anggota', '2024-10-13'),
(4, 12, 'Kesibukan pribadi anggota', '2024-10-27'),
(5, 18, 'Kesibukan pribadi anggota', '2024-10-06');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kegiatan`
--

CREATE TABLE `tbl_kegiatan` (
  `id_kegiatan` int(5) NOT NULL,
  `id_kelompok` int(5) DEFAULT NULL,
  `kegiatan` varchar(255) DEFAULT NULL,
  `waktu_awal` time DEFAULT NULL,
  `waktu_akhir` time DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_kegiatan`
--

INSERT INTO `tbl_kegiatan` (`id_kegiatan`, `id_kelompok`, `kegiatan`, `waktu_awal`, `waktu_akhir`, `tanggal`) VALUES
(1, 1, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(2, 1, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(3, 1, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(4, 1, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(5, 2, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(6, 2, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(7, 2, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(8, 2, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(9, 3, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(10, 3, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(11, 3, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(12, 3, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(13, 4, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(14, 4, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(15, 4, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(16, 4, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(17, 5, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(18, 5, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(19, 5, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(20, 5, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(21, 6, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(22, 6, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(23, 6, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(24, 6, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(25, 7, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(26, 7, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(27, 7, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(28, 7, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(29, 8, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(30, 8, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(31, 8, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(32, 8, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(33, 9, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(34, 9, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(35, 9, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(36, 9, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(37, 10, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(38, 10, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(39, 10, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(40, 10, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(41, 11, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(42, 11, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(43, 11, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(44, 11, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(45, 12, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(46, 12, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(47, 12, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(48, 12, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(49, 13, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(50, 13, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(51, 13, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(52, 13, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(53, 14, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(54, 14, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(55, 14, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(56, 14, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(57, 15, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(58, 15, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(59, 15, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(60, 15, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(61, 16, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(62, 16, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(63, 16, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(64, 16, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(65, 17, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(66, 17, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(67, 17, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(68, 17, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(69, 18, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(70, 18, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(71, 18, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(72, 18, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(73, 19, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(74, 19, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(75, 19, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(76, 19, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27'),
(77, 20, 'Penyemaian benih tanaman baru', '08:00:00', '11:30:00', '2024-10-06'),
(78, 20, 'Membersihkan lahan dari rumput liar dan hama', '08:00:00', '11:30:00', '2024-10-13'),
(79, 20, 'Menggemburkan tanah untuk memastikan tanah tetap subur', '08:00:00', '11:30:00', '2024-10-20'),
(80, 20, 'Penanaman bibit tanaman baru di lahan kebun', '08:00:00', '11:30:00', '2024-10-27');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kelompok`
--

CREATE TABLE `tbl_kelompok` (
  `id_kelompok` int(5) NOT NULL,
  `kode_kelompok` varchar (5) DEFAULT NULL,
  `nama_kelompok` varchar (50) DEFAULT NULL,
  `kid_kelompok` varchar(50) DEFAULT NULL,
  `kecamatan` varchar(50) DEFAULT NULL,
  `mulai_kegiatan` date DEFAULT NULL,
  `akhir_kegiatan` date DEFAULT NULL,
  `notelp_ketua` int(15) DEFAULT NULL,
  `foto_profil` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_kelompok`
--

INSERT INTO `tbl_kelompok` (`id_kelompok`, `kode_kelompok`, `nama_kelompok`, `kid_kelompok`, `kecamatan`, `mulai_kegiatan`, `akhir_kegiatan`, `notelp_ketua`, `foto_profil`) VALUES
(1, 'K0001', 'Srikandi Ceria', '1132474', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(2, 'K0002', 'Berkah', '1097429', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(3, 'K0003', 'Bina Mekar', '1156839', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(4, 'K0004', 'Harap Panjang', '1144854', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(5, 'K0005', 'Srikandi Mandiri', '1130952', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(6, 'K0006', 'Bukit Indah', '1145192', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(7, 'K0007', 'Daun Kelor', '5023740', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(8, 'K0008', 'Kebun Sabilurrosyad', '5023753', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(9, 'K0009', 'Brokoli', '1157011', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(10, 'K0010', 'Sejahtera Bersama', '5023718', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(11, 'K0011', 'Tunas Bersemi', '1157588', 'Tanjungpinang Kota', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(12, 'K0012', 'Tonggok Bambu', '5025306', 'Tanjungpinang Timur', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(13, 'K0013', 'Bhayangkari I', '1118570', 'Tanjungpinang Barat', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(14, 'K0014', 'Tatum Bersemi', '5015463', 'Tanjungpinang Kota', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(15, 'K0015', 'Sekar Sari', '5023741', 'Tanjungpinang Barat', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(16, 'K0016', 'Bhayangkari II', '1118571', 'Tanjungpinang Barat', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(17, 'K0017', 'Serayu', '5023744', 'Tanjungpinang Barat', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(18, 'K0018', 'Bunga Dahlia', '5023752', 'Tanjungpinang Barat', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(19, 'K0019', 'Bukit Semprong', '5015447', 'Tanjungpinang Barat', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png'),
(20, 'K0020', 'Kenanga', '5023815', 'Tanjungpinang Barat', '2024-10-06', '2024-10-27', '081234567890', 'foto_default.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_setting_absensi`
--

CREATE TABLE `tbl_setting_absensi` (
  `id_waktu` int(15) DEFAULT NULL,
  `mulai_absen` time DEFAULT NULL,
  `akhir_absen` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_setting_absensi`
--

INSERT INTO `tbl_setting_absensi` (`id_waktu`, `mulai_absen`, `akhir_absen`) VALUES
(1, '08:00:00', '09:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_site`
--

CREATE TABLE `tbl_site` (
  `id_site` int(5) DEFAULT NULL,
  `nama_instansi` varchar(100) DEFAULT NULL,
  `pimpinan` varchar(50) DEFAULT NULL,
  `kabid_pertanian` varchar(50) DEFAULT NULL,
  `no_telp` varchar(20) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `website` varchar(50) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_site`
--

INSERT INTO `tbl_site` (`id_site`, `nama_instansi`, `pimpinan`, `kabid_pertanian`, `no_telp`, `alamat`, `website`, `logo`) VALUES
(1, 'Dinas Pertanian Pangan dan Perikanan', 'Robert Lukman, S.Pi', 'Dian Fransisca, S.H., M.H', '(0771) 21724', 'Jalan Ahmad Yani No.5, Sei Jang, Kec. Bukit Bestari, Kota Tanjung Pinang, Kepulauan Riau 29122', 'dppptpi.go.id', 'logotanjungpinang.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(5) NOT NULL,
  `kode_pengguna` varchar(5) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `kode_pengguna`, `username`, `password`, `level`) VALUES
(1, 'A0001', 'afaamanda', 'AfaaAmanda691406', 'Admin'),
(2, 'K0001', 'srikandiceria', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(3, 'K0002', 'berkah', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(4, 'K0003', 'binamekar', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(5, 'K0004', 'harappanjang', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(6, 'K0005', 'srikandimandiri', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(7, 'K0006', 'bukitindah', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(8, 'K0007', 'daunkelor', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(9, 'K0008', 'kebunsabilurrosyad', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(10, 'K0009', 'brokoli', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(11, 'K0010', 'sejahterabersama', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(12, 'K0011', 'tunasbersemi', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(13, 'K0012', 'tonggokbambu', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(14, 'K0013', 'bhayangkari01', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(15, 'K0014', 'tatumbersemi', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(16, 'K0015', 'sekarsari', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(17, 'K0016', 'bhayangkari02', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(18, 'K0017', 'serayu', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(19, 'K0018', 'bungadahlia', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(20, 'K0019', 'bukitsemprong', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota'),
(21, 'K0020', 'kenangatpib', 'e10adc3949ba59abbe56e057f20f883e', 'Anggota');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_absensi`
--
ALTER TABLE `tbl_absensi`
  ADD PRIMARY KEY (`id_absensi`),
  ADD KEY `tbl_absensi_ibfk1_1` (`id_kelompok`);

--
-- Indeks untuk tabel `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD KEY `kode_admin` (`kode_admin`);

--
-- Indeks untuk tabel `tbl_alasan`
--
ALTER TABLE `tbl_alasan`
  ADD PRIMARY KEY (`id_alasan`),
  ADD KEY `tbl_alasan_ibfk1_1` (`id_kelompok`);

--
-- Indeks untuk tabel `tbl_kegiatan`
--
ALTER TABLE `tbl_kegiatan`
  ADD PRIMARY KEY (`id_kegiatan`),
  ADD KEY `tbl_kegiatan_ibfk1_1` (`id_kelompok`);

--
-- Indeks untuk tabel `tbl_kelompok`
--
ALTER TABLE `tbl_kelompok`
  ADD PRIMARY KEY (`id_kelompok`),
  ADD KEY `kode_kelompok` (`kode_kelompok`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `kode_pengguna` (`kode_pengguna`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_absensi`
--
ALTER TABLE `tbl_absensi`
  MODIFY `id_absensi` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT untuk tabel `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id_admin` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tbl_alasan`
--
ALTER TABLE `tbl_alasan`
  MODIFY `id_alasan` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tbl_kegiatan`
--
ALTER TABLE `tbl_kegiatan`
  MODIFY `id_kegiatan` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT untuk tabel `tbl_kelompok`
--
ALTER TABLE `tbl_kelompok`
  MODIFY `id_kelompok` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tbl_absensi`
--
ALTER TABLE `tbl_absensi`
  ADD CONSTRAINT `tbl_absensi_ibfk1_1` FOREIGN KEY (`id_kelompok`) REFERENCES `tbl_kelompok` (`id_kelompok`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD CONSTRAINT `tbl_admin_ibfk_1` FOREIGN KEY (`kode_admin`) REFERENCES `tbl_user` (`kode_pengguna`);

--
-- Ketidakleluasaan untuk tabel `tbl_alasan`
--
ALTER TABLE `tbl_alasan`
  ADD CONSTRAINT `tbl_alasan_ibfk1_1` FOREIGN KEY (`id_kelompok`) REFERENCES `tbl_kelompok` (`id_kelompok`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_kegiatan`
--
ALTER TABLE `tbl_kegiatan`
  ADD CONSTRAINT `tbl_kegiatan_ibfk1_1` FOREIGN KEY (`id_kelompok`) REFERENCES `tbl_kelompok` (`id_kelompok`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_mahasiswa`
--
ALTER TABLE `tbl_kelompok`
  ADD CONSTRAINT `tbl_kelompok_ibfk_1` FOREIGN KEY (`kode_kelompok`) REFERENCES `tbl_user` (`kode_pengguna`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
